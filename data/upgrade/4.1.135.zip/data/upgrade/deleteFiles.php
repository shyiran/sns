<?php
return array(
	'addons/model/CaptchaModel.class.php',
	'chat'
);